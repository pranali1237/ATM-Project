import java.io.IOException;

public class ATM extends Menu{
	
	public static void main(String[]args) throws IOException {
		Menu menu = new Menu();
	   menu.getLogin();
	}

}
